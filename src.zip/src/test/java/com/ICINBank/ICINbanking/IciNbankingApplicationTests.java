package com.ICINBank.ICINbanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IciNbankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
