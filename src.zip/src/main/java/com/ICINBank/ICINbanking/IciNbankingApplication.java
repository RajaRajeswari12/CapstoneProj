package com.ICINBank.ICINbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IciNbankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(IciNbankingApplication.class, args);
	}

}
