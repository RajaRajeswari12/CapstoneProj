package com.ICINBank.ICINbanking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ICINBank.ICINbanking.model.ChequeBook;

public interface ChequeBookRepository extends JpaRepository<ChequeBook, Integer> {

}
